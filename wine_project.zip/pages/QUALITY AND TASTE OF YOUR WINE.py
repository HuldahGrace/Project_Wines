import streamlit as st
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image



df = pd.read_csv('C:\\Users\\Sruthi\\Desktop\\wines\\data\\finalwines.csv')


st.title("Quality and Taste of wine :champagne:")


st.write("")

st.subheader(":green[Sensory features when compared with Quality of Wine]")

st.write("")

option = st.selectbox(
   "QUALITY OF...",
   ("Aroma", "Flavor", "Texture", 'Properties'),
   index=None,
   placeholder="Select a sensory property...",
)


st.write("")
st.write("")
st.write("")


#st.write('You selected:', option)

#st.subheader("Boxen Plot for chemical properties based on its sensory characteristics and comapring with quality of wine")


if option == 'Aroma':

    fig, axs = plt.subplots(1,2, figsize=(8,3), constrained_layout=True)

    sns.boxenplot(data=df,y='free_sulfur_dioxide', x='quality',  ax=axs[0])

    sns.boxenplot(data=df,y='total_sulfur_dioxide', x='quality',  ax=axs[1])

    st.pyplot(fig = fig)



if option == 'Texture':

    fig, axs = plt.subplots(1,2, figsize=(8,3), constrained_layout=True)

    sns.boxenplot(data=df,y='chlorides', x='quality',  ax=axs[0])

    sns.boxenplot(data=df, x='quality', y='alcohol', ax=axs[1])

    st.pyplot(fig = fig)



if option == 'Flavor':

    fig, axs = plt.subplots(2,2, figsize=(10,5), constrained_layout=True)

    sns.boxenplot(data=df,y='fixed_acidity', x='quality',  ax=axs[0][0])

    sns.boxenplot(data=df,y='volatile_acidity', x='quality',  ax=axs[0][1])

    sns.boxenplot(data=df,y='residual_sugar', x='quality',  ax=axs[1][0])

    sns.boxenplot(data=df,y='citric_acid', x='quality',  ax=axs[1][1])

    st.pyplot(fig = fig)

if option == "Properties":

    fig, axs = plt.subplots(1,2, figsize=(8,3), constrained_layout=True)

    sns.boxenplot(data=df,y='density', x='quality',  ax=axs[0])

    sns.boxenplot(data=df, x='quality', y='sulphates', ax=axs[1])

    st.pyplot(fig = fig)


st.subheader(":green[Sensory features when compared with Taste of wine]")

st.write("")




option = st.selectbox(
   "TASTE OF...",
   ("Aroma", "Flavor", "Texture", 'Properties'),
   index=None,
   placeholder="Select a sensory property...",
)


#st.write('You selected:', option)



if option == "Aroma":

    fig, axs = plt.subplots(1,2, figsize=(8,3), constrained_layout=True)

    sns.boxenplot(data=df,y='free_sulfur_dioxide', x='good',  ax=axs[0])

    sns.boxenplot(data=df,y='total_sulfur_dioxide', x='good',  ax=axs[1])

    st.pyplot(fig = fig)


if option == 'Texture':

    fig, axs = plt.subplots(1,2, figsize=(8,3), constrained_layout=True)

    sns.boxenplot(data=df,y='chlorides', x='good',  ax=axs[0])

    sns.boxenplot(data=df, x='good', y='alcohol', ax=axs[1])

    st.pyplot(fig = fig)


if option == 'Flavor':

    fig, axs = plt.subplots(2,2, figsize=(10,5), constrained_layout=True)

    sns.boxenplot(data=df,y='fixed_acidity', x='good',  ax=axs[0][0])

    sns.boxenplot(data=df,y='volatile_acidity', x='good',  ax=axs[0][1])

    sns.boxenplot(data=df,y='residual_sugar', x='good',  ax=axs[1][0])

    sns.boxenplot(data=df,y='citric_acid', x='good',  ax=axs[1][1])

    st.pyplot(fig = fig)
