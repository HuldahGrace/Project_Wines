import streamlit as st
from PIL import Image


st.title("Wine Quality Calculator :wine_glass:")

st.write("")


col1, col2 = st.columns(2,gap="small")

with col1:
    fsd = st.number_input (label = "Free sulphur dioxide: ", min_value=1.0 , max_value = 289.0)

    
with col2:
    tsd = st.number_input (label = "Total sulphur dioxide: ", min_value=6.0 , max_value = 440.0)


col1, col2 = st.columns(2,gap="small")
            
with col1:
    d = st.number_input (label = "Density: ", min_value=0.98 , max_value = 1.03)

with col2:
    s = st.number_input (label = "Sulphates: ", min_value=0.22 , max_value = 2.0)
    

col1, col2 = st.columns(2,gap="small")
            
with col1:
    c = st.number_input (label = "Chlorides: ", min_value=0.009 , max_value = 0.61)

with col2:
    a = st.number_input (label = "Alcohol: ", min_value=8.0 , max_value = 14.9)



col1, col2 , col3 , col4 = st.columns(4,gap="small")
            
with col1:
    fa = st.number_input (label = "Fixed acidity: ", min_value=3.8 , max_value = 15.9)

with col2:
    va = st.number_input (label = "Volatile acidity: ", min_value=0.08 , max_value = 1.58)

with col3:
    rs = st.number_input (label = "Residual sugar: ", min_value=0.6 , max_value = 65.8)

with col4:
    ca = st.number_input (label = "Citric acid: ", min_value=0.0 , max_value = 1.66)



if st.button('Submit'):
    if (fsd >= 20 and fsd <= 40) & (tsd >= 90 and tsd <=150) & (d >= 0.99 and d <=1.0) & (s >= 0.4 and s <=0.6) & (c >= 0.03 and c <=0.07) & (a >= 11 and a<=13) & (fa >= 6.0 and fa <=7.0) & (va >= 0.2 and va <=0.3) & (rs >= 2 and rs <=4) & (ca >= 0.3 and ca <=0.4):
        st.write("Good Wine")
    else:
        st.write('Opps! You are almost there, to get that perfect wine quality **Check Our Recommendation Table** :point_down:')
        st.write("")
        st.write("")
        st.write("")
        image = Image.open('Captureg.png')
        st.image(image, caption='Recommendation table')


import base64
import streamlit as st
import plotly.express as px

df = px.data.iris()

@st.cache_data
def get_img_as_base64(file):
    with open(file, "rb") as f:
        data = f.read()
    return base64.b64encode(data).decode()


img = get_img_as_base64("Captureg.png")

page_bg_img = f"""
<style>
[data-testid="stAppViewContainer"] > .main {{
background-image: url("Captureg.png");
background-size: 120%;
background-position: top left;
background-repeat: no-repeat;
background-attachment: local;
opacity = 0.5;
height: 100%;

}}

[data-testid="stSidebar"] > div:first-child {{
background-image: url("data:image/png;base64,{img}");
background-position: center; 
background-repeat: no-repeat;
background-attachment: fixed;
}}

[data-testid="stHeader"] {{
background: rgba(0,0,0,0);
}}

[data-testid="stToolbar"] {{
right: 2rem;
}}
</style>
"""

st.markdown(page_bg_img, unsafe_allow_html=True)





    
