import streamlit as st
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

st.title("Data app on Wine Quality")


df = pd.read_csv('C:\\Users\\Sruthi\\Desktop\\wines\\data\\finalwines.csv')


tab1, tab2 = st.tabs(["Dataset","Features"])

with tab1:
   st.dataframe(df)

with tab2:
   st.header(":green[Characteristics of each property]")
   with st.expander("Chemical Characteristics"):
       st.subheader("FIXED ACIDITY")
       st.write("The total concentration of acids in the wine, which primarily contributes to the wine's overall acidity level.")
       st.subheader("VOLATILE ACIDITY")
       st.write(" The presence of volatile acids which can give a wine a vinegary or sharp taste.")
       st.subheader("CITRIC ACID")
       st.write("An organic acid which adds freshness and acidity to a wine.")
       st.subheader("RESIDUAL SUGAR")
       st.write("Presence of residual sugar influences the wine's sweetness level.")
       st.subheader("CHLORIDES")
       st.write("The concentration of salts which can affect the wine's taste and mouthfeel.")
       st.subheader("FREE AND TOTAL SULFUR DIOXIDE")
       st.write("Sulfur dioxide is used in winemaking as a preservative and antioxidant. It can also affect the wine's aroma and flavor.")
       st.subheader("DENSITY")
       st.write("The mass per unit volume of the wine, which can indicate the concentration of solids (like sugar) in the liquid.")
       st.subheader("pH")
       st.write(" A measure of the wine's acidity or alkalinity. Lower pH values indicate higher acidity.")
       st.subheader("SULPHATES")
       st.write("A Compound that act as antioxidants and antimicrobial agents in wine.")
       st.subheader("ALCOHOL")
       st.write("The percentage of alcohol by volume in the wine, which affects the body, texture, and overall flavor profile.")
       st.subheader("GOOD")
       st.write("1 indicates a GOOD quality and 0 indicates a BAD quality.")
       st.subheader("COLOR")
       st.write("This can be influenced by the grape variety used, as well as the winemaking process i.e. (RED / WHITE).")
       st.subheader("QUALITY")
       st.write("Quality of wine based on each property")


with st.expander("Sensory Characteristics"):
        
    col1, col2 ,col3 , col4 = st.columns(4,gap="small")

    with col1:
        if st.button(":green[Aroma]"):
            st.write('In wine, aromas perception is olfactory and not gustatory which can be include by **Free Sulphur dioxide and Total Sulphur Dioxide**')
                
    
    with col2:
            if st.button(":violet[Flavor]"):
                st.write("In wine, we speak of primary, secondary, the primary flavors come from the grape itself. Secondary flavors come from the winemaking process which include **Alcohol, Fixed Acidity, Volatile Acidity, Citric Acid and Residual Sugar**.")
    
            
    with col3:
        if st.button(':orange[Quality]'):
                st.write("High-quality wines will express intense flavors and a lingering finish, with flavors lasting after you've swallowed the wine. **Density Alochol and Sulphates** helps in producing a high quality wine")
            

        with col4:
            if st.button(":blue[Property]"):
                st.write("The sweetness, acidity, flavor and texture are the four factors working together to make up the wine's body ")
                
                


